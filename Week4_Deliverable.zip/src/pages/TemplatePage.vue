<template>
</template>
  
  <script lang="ts">
  export default {
    name: 'PageName',
  };
  </script>
  
  <script setup lang="ts">
  //Most code goes here
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped>

  
  </style>